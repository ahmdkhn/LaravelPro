
function addGroupInList2Delete()
{

var group=document.getElementById('groupAdded2Delete').innerHTML;
var newGroup = document.getElementById('group2Delete').value;
document.getElementById('groupAdded2Delete').innerHTML = newGroup+"\n"+group;
}



function addGroupInList2Add()
{
var group=document.getElementById('groupAdded2User').innerHTML;
var newGroup = document.getElementById('group2Add').value;
document.getElementById('groupAdded2User').innerHTML =  newGroup+"\n"+group ;
}
