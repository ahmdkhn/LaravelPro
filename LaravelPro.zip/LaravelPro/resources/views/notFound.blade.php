@extends('Main')

@section('content')

<!DOCTYPE html>
<html>
<head>
	<title>404</title>
</head>
<body>

<div class="textBig"> Ooops........... 404 </div>
</h1>
</body>
</html>

@endsection

