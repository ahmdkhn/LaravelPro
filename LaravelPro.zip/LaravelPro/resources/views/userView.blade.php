@extends('Main')

@section('content')
<div class="container-fluid">
<div class="panel panel-default">
<div class="panel-heading">
<h3 class="panel-title">Details of the Groups</h3></div>
<div class="panel-body">
<div class="table-responsive">
	<table class="table table-striped table-bordered">
		<thead>
			<tr>
				<th>User-ID</th>
				<th>User-Name</th>
			</tr>
		</thead>
		<tbody>
		@if(isset($id_name))
			@foreach($id_name as $id_name=>$value)
			<tr>
				<td>{{$id_name}}</td>
				<td>{{$value}}</td>
			</tr>
			@endforeach
			@endif

			@if(isset($users))
			@foreach($users as $users)
			<tr>
				<td>{{$users->id}}</td>
				<td>{{$users->name}}</td>
			</tr>
			@endforeach
			@endif		

		</tbody>

	</table>

</div>
</div>
</div>
</div>
</div>
@endsection

