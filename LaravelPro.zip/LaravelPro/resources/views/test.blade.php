@extends('Main')

@section('content')
    <div class="form-group">
 {{ Form::open(array('url' => 'updateGroup')) }}

        <label class="col-md-3 control-label" for="selectGroup"> Select Group to Add: </label>
        <div class="col-md-9">      
        <select class="form-control" id="selectGroup" name="selectGroup" >
        @foreach ($groups as $groups) 
        <option>{{$groups->group_name}}</option>
        @endforeach               
</select>   
</div>

@endsection

