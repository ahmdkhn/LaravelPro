@extends('Main')

@section('content')

<div class="container-fluid">
<div class="panel panel-default">
<div class="panel-heading">
<h3 class="panel-title">Insert user details</h3>
</div>

<div class="panel-body">
<form role="form" action="{{url('/storeUserInfo')}}" method="POST">
<input type="hidden" name="_token" value="{{csrf_token()}}">
	
	<div class="form-group">
		<label class="col-md-3 control-label"> Enter Group Name: </label>
		<div class="col-md-9">
		<input type="text" class="form-control" name="groupName" value="{{old('groupName')}}" required="true" />
		</br>		
		</div>
	</div>

		<div class="form-group">
		<label class="col-md-3 control-label"> Enter User Name: </label>
		<div class="col-md-9">
		<input type="text" class="form-control" name="userName" value="{{old('userName')}}" required="true" />
		</br>		
		</div>
	</div>
	<div class="form-group">
		<label class="col-md-3 control-label"> Enter Password: </label>
		<div class="col-md-9">
		<input type="text" class="form-control" name="userPassword" value="{{old('userPassword')}}" required="true" />
		</br>		
		</div>
	</div>
<button type="submit" class="btn btn-primary" value="submit">Click 2 Store Data</button>

</form>
</div>
</div>
</div>


@endsection

