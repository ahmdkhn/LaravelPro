<!DOCTYPE html>
<html lang="en">
<head>
 <title>EasiR Task</title> 
</head>
<body>
<nav class="navbar navbar-inverse">
<div class="container-fluid">
<div class="navbar-header">
<a class="navbar-brand" href="{{url('/home')}}">Home</a>
</div>
<div>
	<ul class="nav navbar-nav">
	<li><a href="{{url('/adminView')}}">AdminView</a></li>
	<li><a href="{{url('/userView')}}">UserView</a></li>
	</ul>
</div>
            <div class="collapse navbar-collapse" id="app-navbar-collapse">
               
                <ul class="nav navbar-nav navbar-right">
                  
                    @if (Auth::guest())
                        <li><a href="{{ url('/login') }}">Login</a></li>
                        <li><a href="{{ url('/register') }}">Register</a></li>
                    @else
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                {{ Auth::user()->name }} <span class="caret"></span>
                            </a>

                            <ul class="dropdown-menu" role="menu">
                                <li><a href="{{ url('/logout') }}"><i class="fa fa-btn fa-sign-out"></i>Logout</a></li>
                            </ul>
                        </li>
                    @endif
                </ul>
            </div>
        </div>
    </nav>

</div>

</nav>

<div>
	@if(Session::has('flash_message'))
	<div class="alert alert-success">
		{{Session::get('flash_message')}}

	</div>
	@endif

	@if(count($errors)>0)
	<div class="alert alert-danger"></div>
	<strong>Ohhh..!</strong> There are some errors in your input...! </br> </br>
		<ul>
		@foreach($errors->all() as $error)
			<li>{{$error}}</li>
			@endforeach
		</ul>
</div>
@endif
<div class="container">

	@yield('content')

</div>

 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
	{!!Html::style('project.css')!!}
	{!! HTml::script('project.js') !!}
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"> </script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</body>
</html>