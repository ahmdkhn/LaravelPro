@extends('Main')

@section('content')
{{---Store Group Info:--}}
<div class="container-fluid">
<div class="panel panel-default">
<div class="panel-heading">
<h3 class="panel-title">Create Groups</h3>
</div>

<div class="panel-body">
{!! Form::open(array('url' => '/storeGroupInfo', 'name' =>'delete', 'method' =>'POST')) !!}

<input type="hidden" name="_token" value="{{csrf_token()}}">	
	<div class="form-group">
		<label class="col-md-3 control-label"> Enter Group Name: </label>
		<div class="col-md-9">
		<input type="text" class="form-control" name="groupName" value="{{old('groupName')}}" required="true" />
		</br>		
		</div>
	</div>
	{{Form::submit('Create Group',array('class'=>'btn btn-primary','name'=>'action','value'=>'submit'))}}
    {!! Form::close() !!}
 </div>
 </div>
 </div>















{{---- Delete Groups--}} 

<div class="container-fluid">
<div class="panel panel-default">
<div class="panel-heading">
<h3 class="panel-title">Delete Groups</h3>
</div>

<div class="panel-body">


<form role="form" action="{{url('/deleteGroup')}}" method="POST">
<input type="hidden" name="_token" value="{{ csrf_token() }}">

{{-- {!! Form::open(array('url' => '/deleteGroup','method'=>'POST')) !!}
 --}}

<div class="form-group">
		<label class="col-md-3 control-label" for="delete"> Select Group to Delete: </label>
		<div class="col-md-9">		
  		<select class="form-control" name="delete" value="delete" id="delete">
  		@foreach ($groups as $group) 
        <option>{{$group->name}} </option>
        @endforeach  	
	
</select>	
		</div>
	</div>
	
<button type="submit" class="btn btn-danger" name="deleteGrp" value="deleteGrp">Delete Group</button>

 {{-- {!! Form::close() !!} --}}

</form>

 </div>
 </div>
 </div>

 {{---- Update Groups--}} 

<div class="container-fluid">
<div class="panel panel-default">
<div class="panel-heading">
<h3 class="panel-title">Update Groups</h3>
</div>

<div class="panel-body">

<form role="form" action="{{url('/updateGroupInfo')}}" method="POST">
<input type="hidden" name="_token" value="{{csrf_token()}}">
	
	<div class="form-group">
		<label class="col-md-3 control-label" for="delete"> Select Group: </label>
		<div class="col-md-9">		
  		<select class="form-control" name="updateGroup" value="updateGroup" id="updateGroup">
  	  		@foreach ($groups as $group) 
        <option>{{$group->name}} </option>
               @endforeach  	
</select>	
		</div>
	</div>



	<div class="form-group">
		<label class="col-md-3 control-label"> New Group Name: </label>
		<div class="col-md-9">
		<input type="text" class="form-control" name="groupName" value="{{old('groupName')}}" required="true" />
		</br>		
		</div>
	</div>
<button type="submit" class="btn btn-info" value="submit">Update Group</button>
 </form>
 </div>
 </div>
 </div>






{{------Create User------}}

<div class="container-fluid">
<div class="panel panel-default">
<div class="panel-heading">
<h3 class="panel-title">Create Users</h3>
</div>
<div class="panel-body">




{!! Form::open(array('url' => '/storeUserInfo')) !!}



{{-- <form role="form" action="{{url('/storeUserInfo')}}" method="POST"> --}}
<input type="hidden" name="_token" value="{{csrf_token()}}">

		<div class="form-group">
		<label class="col-md-3 control-label"> Enter User Name: </label>
		<div class="col-md-9">
		<input type="text" class="form-control" name="userName" value="{{old('userName')}}" required="true" />
		</br>		
		</div>
	</div>

	<div class="form-group">
		<label class="col-md-3 control-label"> Enter Password: </label>
		<div class="col-md-9">
		<input type="text" class="form-control" name="userPassword" value="{{old('userPassword')}}" required="true" />
		</br>		
		</div>
	</div>




	<div class="form-group">
		<label class="col-md-3 control-label" for="selectGroupFirst"> Select Group to Add: </label>
		<div class="col-md-9">	


  		<select class="form-control" id="selectGroupFirst" name="selectGroupFirst" >



  	

		@foreach ($groups as $group) 
        <option>{{$group->name}}</option>
        @endforeach   
				
</select>


		</div>
	</div>
<div class="form-group">
		<label class="col-md-3 control-label" for="selectGroupSecond"> </label>
		<div class="col-md-9">	


  		<select class="form-control" id="selectGroupSecond" name="selectGroupSecond" >





		@foreach ($groups as $group) 
        <option>{{$group->name}}</option>
        @endforeach   
				
</select>


		</div>
	</div>
	<div class="form-group">
		<label class="col-md-3 control-label" for="selectGroupThird"></label>
		<div class="col-md-9">	


  		<select class="form-control" id="selectGroupThird" name="selectGroupThird" >




		@foreach ($groups as $group) 
        <option>{{$group->name}}</option>
        @endforeach   
				
</select>


		</div>
	</div>

{{-- <button type="submit" class="btn btn-primary" value="createUser">Create User</button>
<button type="submit" class="btn btn-primary" value="updateUser">Update User</button> --}}

{{Form::submit('Create User',array('class'=>'btn btn-primary','name'=>'action','value'=>'create'))}}
{{-- {{Form::submit('Add More Groups',array('class'=>'btn btn-primary','name'=>'action','value'=>'addMoreGroups'))}} --}}
{{-- {{Form::submit('Delete',array('class'=>'btn btn-primary','data-dismiss'=>'modal','aria-hidden'=>'true','name'=>'action','value'=>'delete'))}} --}}
{{-- {{Form::submit('Save',array('class'=>'btn btn-primary','name'=>'action','value'=>'save'))}}
 --}}
{!! Form::close() !!}
{{-- </form> --}}
</div>
</div>
</div>








{{------Delete User------}}

<div class="container-fluid">
<div class="panel panel-default">
<div class="panel-heading">
<h3 class="panel-title"> Delete User</h3>
</div>
<div class="panel-body">

{!! Form::open(array('url' => '/deleteUser', 'method'=>'POST')) !!}

{{-- <form role="form" action="{{url('/storeUserInfo')}}" method="POST"> --}}
<input type="hidden" name="_token" value="{{csrf_token()}}">

		<div class="form-group">
		<label class="col-md-3 control-label"> Enter User Name: </label>
		<div class="col-md-9">
		<input type="text" class="form-control" name="user2delete" value="{{old('userName')}}" required="true" />
		</br>		
		</div>
	</div>

	<div class="form-group">
		<label class="col-md-3 control-label"> Enter Password: </label>
		<div class="col-md-9">


		<input type="text" class="form-control" name="userPassword" value="{{old('userPassword')}}" required="true" />
		</br>		
		</div>
	</div>

{{-- <button type="submit" class="btn btn-primary" value="createUser">Create User</button>
<button type="submit" class="btn btn-primary" value="updateUser">Update User</button> --}}

{{Form::submit('Delete User',array('class'=>'btn btn-danger','data-dismiss'=>'modal','aria-hidden'=>'true','name'=>'action','value'=>'delete'))}}



{!! Form::close() !!}
{{-- </form> --}}
</div>
</div>
</div>


{{------Update User------}}

<div class="container-fluid">
<div class="panel panel-default">
<div class="panel-heading">
<h3 class="panel-title">Update User details</h3>
</div>
<div class="panel-body">

{!! Form::open(array('url' => '/verifyUserCredentials', 'method'=>'GET')) !!}

{{-- <form role="form" action="{{url('/storeUserInfo')}}" method="POST"> --}}
<input type="hidden" name="_token" value="{{csrf_token()}}">

		<div class="form-group">
		<label class="col-md-3 control-label"> Enter User Name: </label>
		<div class="col-md-9">
  		<input type="text" class="form-control" name="userName" />
		</br>

		</div>
	</div>

		<div class="form-group">
		<label class="col-md-3 control-label"> Enter Password: </label>
		<div class="col-md-9">
		<input type="text" class="form-control" name="userPassword" />
		</br>	
		
		</div>
		{{Form::submit('Verify User Credentials',array('class'=>'btn btn-primary','name'=>'action','value'=>'updateUserDetails'))}}
		</div>		
	{!! Form::close() !!}
	</div>
	</div>
	</div>


{{------- user update ends------}}
@endsection