@extends('Main')

@section('content')

{!! Form::open(array('url' => '/updateAllUserDetails', 'method'=>'PATCH')) !!}
<div class="container-fluid">
<div class="container-fluid">
<div class="panel panel-default">
<div class="panel-heading">
<h3 class="panel-title" id="name"> Account Title:[@if(isset($name)){{$name}}@endif 
 {{ Form::hidden('name', $name) }} ]  Fill the fields that you wan to update:</h3>
</div>
<div class="panel-body">
 <input type="hidden" name="_token" value="{{csrf_token()}}">
	<div class="form-group">
		<label class="col-md-3 control-label"> Enter New Name:</label>
		<div class="col-md-9">
		<input type="text" class="form-control" name="newUserName"  />
		</br>	
		</div>
	</div>
	<div class="form-group">
		<label class="col-md-3 control-label"> Enter New Password: </label>
		<div class="col-md-9">
		<input type="text" class="form-control" name="newUserPassword" />
		</br>		
		</div>
	</div>
	<div class="form-group">
		<label class="col-md-3 control-label" for="group2Delete"> Select Group to Delete: </label>
		<div class="col-md-9">		
  		<select class="form-control" id="group2Delete" name="group2Delete" >	
  		@if (isset($groups))
  		@foreach($groups as $groups)
  		<option>{{$groups}}</option>
	@endforeach
	@endif
</select>	
<div class="spacer"	> </div>
  		
<textarea rows="4" cols="50" name="groupAdded2Delete" id="groupAdded2Delete">
</textarea>
<div class="keepRight" >
<button type='button' onclick='addGroupInList2Delete()'   class="btn btn-danger" id="group2DeleteButton" name="group2DeleteButton"  > Select Group</button> 
</div>
</div>
</div>

<div class="form-group">				
		<label class="col-md-3 control-label" for="group2Add"> Select Group To Add: </label>
		<div class="col-md-9">
		<div class="spacer"> </div>		
  		<select class="form-control" id="group2Add" name="group2Add" >
  		@if(isset($allGroups))
		@foreach ($allGroups as $allGroups) 
        <option>{{$allGroups->name}}</option>
        @endforeach 
        @endif  
</select>	
<div class="spacer"></div>

<textarea rows="4" cols="50" name="groupAdded2User" id="groupAdded2User">
</textarea>
<div class="keepRight" >

<button type='button' onclick='addGroupInList2Add()'   class="btn btn-primary" id="group2beAdded" name="group2beAdded"> Select Group</button> 
</div>
</div>
</div>
</div>
{{Form::submit('Update User Details',array('class'=>'btn btn-success','name'=>'action'))}}
{!! Form::close() !!}
<div class="spacer"></div>

</div>
</div>
</div>

@endsection

