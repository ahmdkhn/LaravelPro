<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/home', 'AdminController@getHome');
Route::get('/adminView', 'AdminController@getAdminView');
Route::get('/userView', 'AdminController@getUserView');
Route::get('/insertInfo', 'AdminController@getInsertInfoView');
Route::post('/storeGroupInfo', 'AdminController@storeGroupInfo');
Route::post('/storeUserInfo', 'AdminController@storeUserInfo');
Route::get('/testNow', 'AdminController@testNow');
Route::post('/deleteGroup','AdminController@deleteGroup');
Route::post('/updateGroupInfo', 'AdminController@updateGroupInfo');
Route::post('/deleteUser','AdminController@deleteUser');
Route::get('/verifyUserCredentials','AdminController@verifyUserCredentials');
Route::post('/enterNewUserDetails', 'AdminController@enterNewUserDetails');
Route::patch('/updateAllUserDetails', 'AdminController@updateAllUserDetails');
Route::auth();
