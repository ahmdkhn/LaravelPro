<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use Session;
use Illuminate\Support\Str;
use App\User;
use App\Group;
use App\GroupUser;
use View;
use Redirect;
use Hash;
use Auth;

class AdminController extends Controller
{
   
public function storeGroupInfo(Request $request)
{

    // if (Group::where('group_name', '=', $request->get('groupName'))->exists()) 
    // {
    //   //  Flash::error('Oh.. ' .groupName. 'already exists..!');     // } 

  $group2create=$request->get('groupName');
  DB::table('group')->insert(array('name' => $group2create));
   $request->session()->flash('flash_message', "Group saved successfully");
    return redirect()->back();
}

public function deleteGroup(Request $request) {        
$group2delete=$request->get('delete');
$groupID=DB::table('group')->where('name','=',$group2delete)->pluck('id'); 
$groupID=implode($groupID);     
$userIDs=DB::table('user_group')->where('group_id','=',$groupID)->pluck('user_id');
echo count($userIDs);
if (count($userIDs)==0)
{
    DB::table('group')->where('id','=',$groupID)->delete($groupID);
    return redirect()->back();
}

else{

    foreach($userIDs as $id)
    {
        $user=User::find($id);
        $user->groups()->detach($groupID);
    }
DB::table('group')->where('id','=',$groupID)->delete($groupID);
return redirect()->back();
}
    }

public function updateGroupInfo(Request $request){
    $group2Rename=$request->get('updateGroup');
    $groupNewName=$request->get('groupName');
   $groupID = DB::table('group')->where('name', '=' , $group2Rename)->pluck('id');
   DB::table('group')->where('id','=', $groupID)->update(array('name' => $groupNewName));
   return redirect()->back();
}

public function storeUserInfo(Request $request)
{
  $Group = new Group;
  $user  = new User;
  $group  = new GroupUser;
  $user->name=$request->get('userName');
  $user->password = Hash::make($request->get('userPassword'));
  $group_nameFirst=$request->get('selectGroupFirst');
  $group_nameSecond=$request->get('selectGroupSecond');
  $group_nameThird=$request->get('selectGroupThird');
  //echo $user->name;
  $test4equality=array($group_nameFirst,$group_nameSecond);  
      if (in_array($group_nameThird,$test4equality))
{

echo "Ooops......Select Unique Groups.";
    
 } else {
    $groups = array($group_nameFirst,$group_nameSecond,$group_nameThird);
    $groupIDs=$group->getGroupIDs($groups); 
    $user->save();

    $userID=DB::table('user')->where('name', '=',$user->name)->pluck('id');
    $userID=implode($userID);
    $group->saveGroupsWithUsers($userID, $groupIDs);
    return redirect()->back();
 }

}

    public function deleteUser(Request $request)
    {
      $user2delete=$request->get('user2delete');
      $verificationPassword=$request->get('userPassword');
           $userName = DB::table('user')->where('name', $user2delete)->pluck('name');

     $userID = DB::table('user')->where('name', $user2delete)->pluck('id');
     $user = User::find(implode($userID));
     $isThisSamePassword= Hash::check($verificationPassword,$user->getAuthPassword());
     $isThisSameName= strcasecmp(implode($userName),$user2delete);
    if ($isThisSamePassword==true && $isThisSameName==0)
    {
     DB::table('user')->where('name','=',$user2delete)->delete();
     return redirect()->back();
    }
    else {
      return view('/notFound');
     }
    }

public function testNow() {
   $Group= new Group;
   $groups = $Group::all();
   return view('test')->with('groups',$groups);
}

public function verifyUserCredentials(Request $request) {
     $user= new User;
     $user2Verify = $request->get('userName');
     $password2Verify=$request->get('userPassword');
    if ( strcmp ($user2Verify,"")==0 && strcmp($password2Verify,"")==0)
    {
        return view('notFound');
    }
     $verify=$user->verifyUser($user2Verify, $password2Verify);

if ($verify==0){
$this->enterNewUserDetails($user2Verify);
return view('updateAllUserDetails')->with('name',$user2Verify);
}
else {
   return view('notFound');
}
}
public function enterNewUserDetails($user2Verify)
{

$userID =  DB::table('user')->where('name','=',$user2Verify)->pluck('id');
$userID=implode($userID);
$userGroups= DB::table('user_group')->where('user_id','=',$userID)->pluck('group_id');
$groups=array();
foreach($userGroups as $group)
{
   $groups[]=DB::table('group')->where('id','=',$group)->pluck('name');
}
$groups=array_flatten($groups);
View::share('groups', $groups);
$allGroups=Group::All();
View::share('allGroups', $allGroups);
return view('updateAllUserDetails')->with('groups',$groups);
}

public function updateAllUserDetails(Request $request){
$oldUserName=$request->get('name');
$newUserName=$request->get('newUserName');
$newUserPassword=$request->get('newUserPassword');
$groupAdded2Delete=$request->get("groupAdded2Delete");
$normalizedList2DeleteGroups=$this->removeDuplicatesFromGroupList($groupAdded2Delete);
$groupAdded2UserList=$request->get("groupAdded2User");
$normalizedList2AddGroups=$this->removeDuplicatesFromGroupList($groupAdded2UserList);
$this->addUserInfo2DataBase($oldUserName, $newUserName,$newUserPassword,$normalizedList2AddGroups,$normalizedList2DeleteGroups);

if ($newUserName!=null)
{
$userid=DB::table('user')->where('name','=',$newUserName)->pluck('id');
}
else if($newUserName==null)
{
    $userid=DB::table('user')->where('name','=',$oldUserName)->pluck('id');
}
$userName=DB::table('user')->where('id','=',implode($userid))->pluck('name');
$id_name=array_combine($userid,$userName);
view::share('id_name',$id_name);
$userid=implode($userid);
$combinedList=$this->getUserGroups($userid);
/*view::share('')*/
 return view('adminView')->with('combinedList', $combinedList);
}

public function getUserGroups($userid)
{
$user= User::find($userid);
$group= new Group;
$grp=array();
foreach ($user->groups as $group)
{
  array_push($grp,$group->pivot->group_id); 
}

$grpName=array();
for($i=0;$i<count($grp);$i++)
{
    array_push($grpName,array_flatten(DB::table('group')->where('id','=', $grp[$i])->pluck('name'))); 
}

$grpName=array_flatten($grpName);
$combinedList= array_combine($grp,$grpName);
   return $combinedList;
}

public function addUserInfo2DataBase($oldUserName,$newUserName,$newUserPassword,$normalizedList2AddGroups,$normalizedList2DeleteGroups)
{
  $userID=DB::table('user')->where('name','=',$oldUserName)->pluck('id');
    $userID= implode($userID);

    if ($newUserName!="") {
    DB::table('user')->where('name','=',$oldUserName)->update(array('name' => $newUserName));
     }

   if($newUserPassword!="") {

$newUserPassword=Hash::make($newUserPassword);

    DB::table('user')->where('name','=', $newUserName)->update(array('password'=>$newUserPassword));
   }
    $normalizedList2Delete=$this->getGroupIDs($normalizedList2DeleteGroups);
    $normalizedList2Add=$this->getGroupIDs($normalizedList2AddGroups);
     $user=User::find($userID);
for ($i=0;$i<count($normalizedList2Delete);$i++)  {   
    $user->groups()->detach($normalizedList2Delete[$i]);
} 

 for($i=0;$i<count($normalizedList2Add);$i++) {
    $group=Group::find($normalizedList2Add[$i]);
    if ($user->groups->contains($group)){
             } 
     else {
 $user->groups()->attach($group);

 }

 }    
}

public function getGroupIDs($listOfGroups){
   $groupIdList = array();
    for ($i=0;$i<count($listOfGroups);$i++){
       $groupEelement=DB::table('group')->where('name','=', $listOfGroups[$i])->pluck('id');
        $groupEelement=implode($groupEelement);
     array_push($groupIdList,$groupEelement);
    }
    return $groupIdList;
}

public function removeDuplicatesFromGroupList($groupAdded2Delete)
{
$normalizedGroupList=array();
$List2delete=explode("\n",$groupAdded2Delete);
for ($i =0;$i<count($List2delete);$i++){
    if (strlen($List2delete[$i])>2) {
        array_push($normalizedGroupList,rtrim($List2delete[$i]));    }
}
$normalizedGroupList=array_unique($normalizedGroupList);
return $normalizedGroupList;
}

public function getHome() {
        return view('/home');
    }

    public function getAdminView() {
    $users=User::all();
    view::share('users', $users);
    $groups=Group::all();    
    return view('adminView')->with('group',$groups);
    }

    public function getUserView() {
     //dd(User::all());
     return view('userView');
      }

 public function getInsertInfoView(){
        $groups=Group::all(); 
        return view('insertInfo')->with('groups',$groups);
}


public function __construct()
{
    $this->middleware('auth');
}


//--------------Methods4EasiR------------------


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    public function store()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }




}
