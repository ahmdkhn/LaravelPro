<?php

namespace App;
use DB;
use App\User;
use App\GroupUser;

use Illuminate\Database\Eloquent\Model;

class Group extends Model
{
    protected $table='group';
    protected $fillable=['id','name'];


public function getGroupName($groupid)
{
 return DB::table('group')->where('id', '=' , $groupid)->pluck('id');
}

public function getALlRecords(){

	$test =Group::all()->pluck('id')->last(); 
	  echo $test;
}

public function users()
{
	return $this->belongsToMany('App\User', 'group_users','user_id','group_id');
}

}
