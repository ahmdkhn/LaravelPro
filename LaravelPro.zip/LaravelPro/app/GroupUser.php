<?php

namespace App;
use DB;
use Illuminate\Database\Eloquent\Model;
use App\User;
use App\Group;

class GroupUser extends Model
{  
protected $table='user_group';
protected $fillable =['user_id','group_id'];
public function getGroupIDs($groups)
{
$groupIDs=array();
foreach($groups as $group)
{

$groupID=DB::table('group')->where('name', '=' , $group)->pluck('id');
$groupIDs[]=$groupID;
}
return $groupIDs;
}
public function saveGroupsWithUsers($user_id, $groupIDs){
$groupUser = new GroupUser;
$user= User::find($user_id);
foreach($groupIDs as $groupID)
{
$group=Group::find($groupID);
$user->groups()->attach($group);
}
}
}


