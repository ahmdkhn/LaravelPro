<?php
namespace App;
use App\GroupUser;
use App\Group;
use DB;
use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;
 use Illuminate\Auth\Passwords\CanResetPassword;
 use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
 use Illuminate\Contracts\Auth\CanResetPassword as CanResetPasswordContract;
use Auth;
 use Hash;

class User extends Model implements AuthenticatableContract, CanResetPasswordContract {
 use Authenticatable, CanResetPassword;

protected $hidden = ['password', 'remember_token'];
protected $table='user';
protected $fillable=['id','name','password'];
public function groups() {
	return $this->belongsToMany('App\Group', 'user_group','user_id','group_id');
}

public function verifyUser($user2Verify, $password2Verify)
{

  $passWordInDB=DB::table('user')->where('name','=',$user2Verify)->pluck('password');
  $name2verify= DB::table('user')->where('name','=',$user2Verify)->pluck('name');
  $UserIDInDB=DB::table('user')->where('name','=',$user2Verify)->pluck('id');
  $user = User::find(implode( $UserIDInDB));
  $isThisSamePassword=Hash::check($password2Verify, $user->getAuthPassword());
  $isThisSameUser=strcasecmp(implode($name2verify),$user2Verify);
 if ( $isThisSamePassword==1 && $isThisSameUser==0 )
  {
   return 0;
    }

  else {
    return 1;
 }

}


private function getUserID($user_name)
{
		$user_id=DB::table(user)->where('name','=',$user_name)->pluck('id');
		return $user_id;
}

private function getUserName($user_id)
{
		$user_name=DB::table(user)->where('id','=',$user_id)->pluck('name');
		return $user_name;
}

private function saveUser($user_name, $user_password)
{		
$this->user_name=$user_name;
$this->password=$user_password;
GroupUser::save();
echo "user saved";
}

}