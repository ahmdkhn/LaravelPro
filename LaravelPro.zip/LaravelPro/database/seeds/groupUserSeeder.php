<?php

use Illuminate\Database\Seeder;
use Faker\Factory as Faker;


use App\Group;
use App\GroupUser;
use App\User;

class GroupUserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */


  
    public function run()
    {
    	 $faker = Faker::create();
         for ($i=1;$i<=10;$i++)
       {
     /* GroupUser::create ([
			'user_id'-> DB::raw('NOW()'),
			'group_id'-> 'user_id'
         ]);*/
       }
    }
}
