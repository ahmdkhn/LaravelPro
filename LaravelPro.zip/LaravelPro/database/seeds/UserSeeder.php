<?php

use Illuminate\Database\Seeder;
use Faker\Factory as Faker;
use App\Group;
use App\GroupUser;
use App\User;

use Hackzilla\PasswordGenerator\Generator\ComputerPasswordGenerator;



class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */


    public function run()
    {


    	$generator = new ComputerPasswordGenerator();

		$generator->setOptionValue(ComputerPasswordGenerator::OPTION_UPPER_CASE, true)
  		->setOptionValue(ComputerPasswordGenerator::OPTION_LOWER_CASE, true)
  		->setOptionValue(ComputerPasswordGenerator::OPTION_NUMBERS, true)
  		->setOptionValue(ComputerPasswordGenerator::OPTION_SYMBOLS, false);

    	
      $groups = Group::lists('name')->all();
      for ($i=1;$i<=10;$i++)
      {
      $faker = Faker::create();
      $password = $generator->generatePassword();
      User::create([
			'id'=>"id:- ". "$i",
			'name'=>$faker->userName(),
			'password'=>$password
		//	'group_name'=> $faker->randomElement($groups)			             

			]);

      }

    }
}
