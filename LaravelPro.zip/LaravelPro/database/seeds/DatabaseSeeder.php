<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;



use App\Group;
use App\GroupUser;
use App\User;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
           


       $this->call('GroupSeeder');
        $this->command->info('GroupSeeder table has been seeded!');
        $this->call('UserSeeder');
        $this->command->info('UserSeeder table has been seeded!');
        $this->call('GroupUserSeeder');
        $this->command->info('GroupUserSeeder table has been seeded!');


    }
}
