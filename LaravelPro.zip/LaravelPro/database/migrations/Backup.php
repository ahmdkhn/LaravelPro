<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Backup extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
       public function up()
    {
/*
 Schema::create('users', function (Blueprint $table) {
            $table->increments('user_id');
            $table->string('user_name')->unique();
            $table->string('password');         
            $table->timestamps();

        });

 Schema::create('groups', function (Blueprint $table) {
            $table->increments('group_id');
            $table->string('group_name')->unique();
            $table->timestamps();
        });

     Schema::create('user_group', function (Blueprint $table) {
        $table->increments('user_group_id');
         $table->integer('user_id')->unsigned()->nullable();
         $table->foreign('user_id')->references('user_id')->on('users')->onDelete('cascade'); 
         $table->integer('group_id')->unsigned()->nullable();
         $table->foreign('group_id')->references('group_id')->on('groups')->onDelete('cascade');
         $table->timestamps();*/
    });
 }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
